#include<iostream>
using namespace std;

int main()
{
    int c=100-50;
    c=10/2;
    c=10*2;
    int a=20;
    a++;
    ++a;
    int b;
    b=20;
    b--;
    --b;
    
    float b=10.5;
    b=20.567*30;

    double c=3.586;
    c=3.708-6.398;

    bool j=false;
    j=true-1;

    char l='0';
    l='q';
    float res = 1 && true;

    bool res2;
    res2 = 0 || true;

}