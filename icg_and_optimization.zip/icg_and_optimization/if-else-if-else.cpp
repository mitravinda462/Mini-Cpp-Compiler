#include<iostream>
using namespace std;
int main()
{
	int a=2;
	int b=2;
	
	if( a< b )
	{
       
       a=1;
       
    }
    else if(a>b)
    {
    	a=2;
    }
    else if(a==b)
    {
    	a=3;
    }
    else
    {
    	a=4;
    }
   	
   	  
    b=0;
    return b;
}
