#include<iostream>
using namespace std;
int main()
{
	int a=2;
	int b=2;
	for(int i=0;i<=10;i++)
    {
    	a++;
    	b--;
    	
    }
	b=2;
}
