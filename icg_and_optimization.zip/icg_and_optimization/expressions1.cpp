#include<iostream>
using namespace std;
int main()
{
	int a=3;
	int a=4;
    int d;
    b=a+5;
    a=c*e;
    d=c*e;
    b=a+d;
    int i;
    int y=i;
    a=y+6;
    a++;
    return x;
}