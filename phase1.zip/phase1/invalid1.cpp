#include<iostream>
using namespace std;
int main()
{
    int a=10;
    if(a)
    {
        a=a+1;
    }
    while(a)
    {
        int i;
        i=i+1;
    }
    i=i+1;
}